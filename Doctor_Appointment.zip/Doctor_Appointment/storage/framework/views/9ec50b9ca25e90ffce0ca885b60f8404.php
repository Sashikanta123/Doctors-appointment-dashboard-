<?php $__env->startSection('title', 'dashboard'); ?>


<?php $__env->startSection('content'); ?>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f4f4f4;
    }
    .container {
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
    }
    th, td {
        padding: 10px;
        border: 1px solid #ccc;
    }
    th {
        background-color: #f2f2f2;
        text-align: left;
    }
    tr:nth-child(even) {
        background-color: #f2f2f2;
    }
    td.text-right {
        text-align: right;
    }
</style>
<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary" style="background-color: #777575;padding-top:1px; font-size:larger;" >
        <div class="container-fluid">
             <h1>Doctors Appointments</h1>
        </div>
        </nav>
    <div class="container">
        <table>
            <thead>
                <tr>
                    <th>Sl No</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Timing</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>3</td>
                    <td>John Doe</td>
                    <td>john@example.com</td>
                    <td>10:00 AM</td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>Jane Smith</td>
                    <td>jane@example.com</td>
                    <td>02:30 PM</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>Michael Johnson</td>
                    <td>michael@example.com</td>
                    <td>04:45 PM</td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>sashi Johnson</td>
                    <td>sashi@example.com</td>
                    <td>05-6pm</td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>pratik kumar</td>
                    <td>pratik@example.com</td>
                    <td>6PM-7pm</td>
                </tr>
                <tr>
                    <td>8</td>
                    <td>taranjeet</td>
                    <td>taran@example.com</td>
                    <td>5PM-7pm</td>
                </tr>
                <tr>
                    <td>9</td>
                    <td>harshit kumar</td>
                    <td>harshit@example.com</td>
                    <td>3pm-4pm</td>
                </tr>
                <tr>
                    <td>10</td>
                    <td>devashis</td>
                    <td>devashish@example.com</td>
                    <td>9am-10am</td>
                </tr>
                <tr>
                    <td>11</td>
                    <td>aditya</td>
                    <td>aditya@example.com</td>
                    <td>10am-11am</td>
                </tr>
                <tr>
                    <td>12</td>
                    <td>sunny</td>
                    <td>sunny@example.com</td>
                    <td>11am-12am</td>
                </tr>
                <tr>
                    <td>13</td>
                    <td>vaibhav</td>
                    <td>vaibhav@example.com</td>
                    <td>12am-1pm</td>
                </tr>
                <tr>
                    <td>14</td>
                    <td>gopal</td>
                    <td>gopal@example.com</td>
                    <td>2pm-3pm</td>
                </tr>

            </tbody>
        </table>
    </div>
</body>
</html>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Doctor.Layout.Doc.Header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\OneDrive\Desktop\Doctor_Appointment\resources\views/Doctor/dashboard.blade.php ENDPATH**/ ?>