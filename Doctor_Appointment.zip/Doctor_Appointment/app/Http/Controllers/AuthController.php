<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\support\Facades\validator;
use App\Models\User;

class AuthController extends Controller
{
     public function rules($data){
        $messages =[
            'email.required' => 'please enter your email address',
            'email.exists'  => 'Email already exist',
            'email.email' => 'please enter a valid email',
            'password.required' => 'password is required',
            'password.min' => 'password must be at least 6 charecters',
        ];

        $validator = validator::make($data, [
            'email' => 'required|email|exist:users',
            'password' => 'required'
        ],$messages);
     }
     public function savedoc(Request $request)
     {
        
        // $request->validate([
         //   'name' =>'required|string|regex:/^[a-zA-Z],{3,16}/i',
         //   'email' =>'required|unique:users|regex:/(.+)@(.+)\.(.+)/i',
         //   'password' =>'required|min:6|confirmed',
          //  'password_confirmation' => 'sometimes|required_with:password'
         //]);

         $users = new User([
            'name' => $request->get('name'),
            'email' => $request->get('email'),
            'password' => $request->get('password'),
            'user_type' => 'doctor'
         ]);
         $users->save();
         
         return redirect()->intended('/doctor/dashboard');
     }
}
